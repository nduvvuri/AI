#!/usr/bin/python

import state
import sys
import heapq
import environment
from pprint import pprint

class Search(object):
    'Implementation of A Star algorithm'


    direction_priority = {'N':0,'E':1,'S':2,'W':3}
    
    ##
    #
    # Member data
    #  frontier: array of States
    #  visited : array of States
    #  environment: pointer to the global environment
    #
    ##
    
    def __init__(self, initial_state,environment, frontier=[], visited=[]):
        self.frontier = frontier
        self.visited = visited
        self.initial_state = initial_state
        self.environment = environment
        self.frontier_set = {}
        self.real_visited = []

    ##
    # This method should return a triplet of:
    #  solution: instance of State that represents a goal state, or None if no goal state is found.
    #  frontier: array of states which are in the frontier at the end of the search.
    #  visited:  array of states that have been expanded during the search.
    #
    ##
    
    def search(self):
        global current_state
        goal_state = None
        x = []
        time_stamp = 0
        self.frontier = environment.PriorityQueue()
        #print ('Inserting the following initial element into Priority Queue : {}'.format(self.initial_state.pos))
        self.frontier.put(self.initial_state, 0, time_stamp)
        self.frontier_set[self.initial_state.pos] = 0

        while not self.frontier.empty():
            #print 'Initial details in Frontier :: {} '.format(self.frontier.elements)
            node_valid_neighbors = []
            current_state = self.frontier.get()
            self.visited.append(current_state.pos)
            self.real_visited.append(current_state)
            #print(self.visited)
            self.frontier_set.pop(current_state.pos)
            #print ('Current Cell : {} . last cell to reach : {}'.format(current_state.pos, self.environment.fetchEndCoordinates()))
            if current_state.pos == self.environment.fetchEndCoordinates():
                break
            for next in current_state.fetch_neighbors():
                if self.environment.validateXY(next[0],next[1]) and ((next[0],next[1]) not in self.visited):
                    node_valid_neighbors.append(next)
                    #cost calculation
                    #self.frontier.append
                    delta_cost = self.calculate_cost(current_state.pos,next)
                    # To-DO should be tracked separately 
                    cost_incurred_so_far = delta_cost + current_state.cost_so_far
                    if cost_incurred_so_far > self.environment.fetchMaxCost():
                        continue
                    ##print 'Cost Details - delta /intermediate cost : {} , initial-state-cost : {} , cost_so_far is {}'.format(delta_cost,self.initial_state.cost_so_far, cost_incurred_so_far)
                    # Overall cost + heuristics
                    effort = cost_incurred_so_far + self.heuristic(next,self.environment.fetchEndCoordinates())
                    #print 'Effort estimated for frontier {} is {}'.format(next,effort)
                    if (next[0], next[1]) in self.frontier_set:
                        existing_cost = self.frontier_set[(next[0],next[1])]
                        if (existing_cost > cost_incurred_so_far ):
                            self.updatefrontier(current_state, next, effort, cost_incurred_so_far)
                            self.frontier_set[(next[0],next[1])] = cost_incurred_so_far
                    else:
                        time_stamp = time_stamp + 1 
                        self.addfrontier(current_state, next,effort,cost_incurred_so_far, time_stamp)
                        self.frontier_set[(next[0],next[1])] = cost_incurred_so_far
     
        # Decision making logic if any should go here.
        # how to represent/calculate goal_state ?
        
        final_state = current_state
        if self.environment.fetchMaxCost() >= final_state.cost_so_far:
            solution = final_state
        else:
            solution = None
        self.frontier.elements = self.getFrontier()
        return (solution, self.frontier, self.real_visited)
    
    ##
    #  This method calculates the cost of movement : Uphill, Downhill, Flat
    #
    ##

    def calculate_cost(self,current_pos,next):
        
        if (self.elevation(next[0],next[1]) > self.elevation(current_pos[0], current_pos[1])):
            #print 'Uphill Move. Calculating movement cost'
            delta_cost = self.uphill_move_cost(next [0],next [1],current_pos [0],current_pos [1])
        else :
            #print 'Downhill or Flat Move. Calculating movement cost'            
            delta_cost = self.downhill_move_cost(next [0],next [1],current_pos [0],current_pos [1])

        return delta_cost

    ##
    #  Fetch all values of Frontier as a reversed list
    #
    ##

    def getFrontier(self):
        lst = []
        while (len(self.frontier.elements) > 0):
            n = self.frontier.get()
            lst.append(n)
        lst.reverse()
        return lst

    ##
    #  This method adds the next node as a Frontier to the current node.
    #  It considers the current state (Node) and builds the next state along with cost & overall effort
    #  Adds the node to the frontier
    #
    ##
    def addfrontier(self, current_state, next, effort,cost, time_stamp):
        #next.updateParent(current_state,cost,next[2])
        moves = current_state.moves_so_far[:]
        moves.append(next[2])
        new_state = state.State(next[0], next[1], current_state, moves, cost )
        self.frontier.put(new_state, effort, time_stamp)
        #print 'Details in Frontier :: {} '.format(self.frontier.elements)
        return new_state

    def updatefrontier(self, current_state, next, effort,cost):
        frontier_contents = []
        temp_element = self.frontier.get_withP()
        effort_e = temp_element[0]
        temp_state = temp_element[1]
        temp_ts = temp_element[2]
        while (temp_element != None ):
            if (temp_state.pos != (next[0],next[1])):
                frontier_contents.append(temp_element)
                temp_element = self.frontier.get_withP()
                effort_e = temp_element[0]
                temp_state = temp_element[1]
                temp_ts = temp_element[2]
            else:
                for temp_element in frontier_contents:
                    self.frontier.put(temp_element[1], temp_element[0], temp_element[2])
                new_state = self.addfrontier(current_state, next, effort,cost, temp_ts)
                return new_state

        return current_state

    
    def addfrontier2(self, current_state, next, effort,cost):
        bnotFound = True
        #print ('Current State : {} ,  Next Node : {}'.format(current_state, next))
        #print 'Details in Frontier :: {} '.format(self.frontier.elements)
        for node in self.frontier.elements:
            #print 'Frontier node value split {} , {} '.format(node[0],node[1])
            if (node[1].pos == next):
                bnotFound = False
                if effort < node[0] :
                    node[1].updateParent(current_state, cost, next[2])
                    #node[1] = self.direction_priority[next[2]] -- TO-DO Add this back
                    node[0] = effort
                    # TO-DO
                    #heapq.heapify(self.frontier)
                break
        if bnotFound == True :
            for node in self.visited :
                #print ('Visited Node : {} , Next Node : {} '.format(node,next))
                if node == (next[0],next[1]) :
                    bnotFound = False
                    break
        if bnotFound == True :
            moves = current_state.moves_so_far[:]
            moves.append(next[2])
            #print ('Current loaded Moves : {} & Cost : {}'.format(moves, cost))
            new_state = state.State(next[0], next[1], current_state, moves, cost)
            #print 'new_state is {}'.format(new_state)
            #self.frontier.put(new_state, [effort,self.direction_priority[next[2]]])
            self.frontier.put(new_state, effort)
            #print 'Details in Frontier :: {} '.format(self.frontier.elements)

    ##
    #  Calculates the heuristics of moving from current node to the next node
    #
    ##

    def heuristic(self,goal, current):
        (x_current_pos, y_current_pos) = (current[0],current[1])
        (x_goal_pos, y_goal_pos) = (goal[0],goal[1])
        return (abs(x_current_pos - x_goal_pos) + abs(y_current_pos - y_goal_pos)
                + abs(self.elevation(x_current_pos,y_current_pos) 
                    - self.elevation(x_goal_pos,y_goal_pos)) 
                )
    
    ##
    #  Returns the elevation of this node based on x & y co-ordinates
    #
    ##

    def elevation(self,x_pos, y_pos):
        return self.environment.elevations[y_pos][x_pos]

    ##
    #  Returns the up-hill move cost
    #
    ##

    def uphill_move_cost(self,x_new_pos,y_new_pos,x_old_pos,y_old_pos):
        return ( 1 + pow(self.elevation(x_new_pos,y_new_pos) - self.elevation(x_old_pos,y_old_pos),
                         2)
               )
    
    ##
    #  Returns the down-hill move cost
    #
    ##

    def downhill_move_cost(self,x_new_pos,y_new_pos,x_old_pos,y_old_pos):
        return (1 + self.elevation(x_old_pos,y_old_pos) - self.elevation(x_new_pos,y_new_pos))
