#!/usr/bin/python

import state
import sys
import heapq

class Environment:
    'Map-based environment'

    # Member data
    # elevations: raw data for each position, stored in a list of lists
    #             (each outer list represents a single row)
    # height: number of rows
    # width: number of elements in each row
    # end_x, end_y: location of goal

    def __init__(self, mapfile, energy_budget, end_coords):
        self.elevations = []
        self.height = 0
        self.width = -1
        self.end_x, self.end_y = end_coords
        self.energy_budget = energy_budget
        # Read in the data
        for line in mapfile:
            nextline = [ int(x) for x in line.split() ]
            #print ('Structure of nextLine {}'.format(nextline))
            if self.width == -1:
                self.width = len(nextline)
            elif len(nextline) == 0:
                sys.stderr.write("No data (or parse error) on line %d\n"
                                 % (len(self.elevations) + 1))
                sys.exit(1)
            elif self.width != len(nextline):
                sys.stderr.write("Inconsistent map width in row %d\n"
                                 % (len(self.elevations) + 1))
                sys.stderr.write("Expected %d elements, saw %d\n"
                                 % (self.width, len(nextline)))
                sys.exit(1)
            self.elevations.insert(0, nextline)
        self.height = len(self.elevations)
        #print ('self.elevations --> {} || self.height --> {} || self.width --> {}' .format(self.elevations,self.height,self.width))
        if self.end_x == -1:
            self.end_x = self.width - 1
        if self.end_y == -1:
            self.end_y = self.height - 1
    
    ##
    #  Returns the end-coordinates loaded into the environment
    #
    ##

    def fetchEndCoordinates(self):
        return (self.end_x, self.end_y)
 
    ##
    #  Returns the energy budget allocated
    ##

    def fetchMaxCost(self):
        return self.energy_budget


    ##
    # Validate whether the x & y co-ordinates are within the boundaries
    ##

    def validateXY(self,x,y):
        return y>=0 and y < len(self.elevations) and x >= 0 and x < len(self.elevations[y])

 # Priority Queue Class
 # A wrapper representation for a heapq / priority queue implementation

class PriorityQueue(object):

    def __init__(self): 
        self.elements = []
    
    def empty(self):
        return len(self.elements) == 0
    
    def put(self, item, priority,time_stamp):
        heapq.heappush(self.elements, (priority,item,time_stamp))

    def getElementWithLowestTs(self):
        #return heapq.heappop(self.elements)[1]
        temp_contents =[]
        temp_triple = heapq.heappop(self.elements)
        min_ts = temp_triple[2]
        if (len(self.elements) > 1):
            temp_contents.append(temp_triple)
            temp_element = heapq.heappop(self.elements)
            while (temp_element!= None):
                if (temp_element[0] != temp_triple[0]):
                    self.put(temp_element[1], temp_element[0], temp_element[2])
                    break
                temp_contents.append(temp_element)
                if min_ts > temp_element[2]:
                    min_ts = temp_element[2]
                if len(self.elements) != 0:
                    temp_element = heapq.heappop(self.elements)
                else:
                    temp_element = None
            
            toReturn= temp_triple
            if len(temp_contents) > 1:
                for temp_element in temp_contents:
                    if (temp_element[2] != min_ts):
                        self.put(temp_element[1], temp_element[0], temp_element[2])
                    else:
                        toReturn = temp_element
            return toReturn
        else:
            return temp_triple

    
    def get(self):
        element = self.getElementWithLowestTs()
        return element[1]

    def get_withP(self):
        element = self.getElementWithLowestTs()
        return element 
    
    def __str__(self):
        temp_contents =[]
        for element in self.elements:
            temp_contents.append(element[1])
        return temp_contents  



