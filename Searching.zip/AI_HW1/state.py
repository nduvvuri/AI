#!/usr/bin/python

import sys
import environment

class State:
	'Implementation of State class and represents a single node'

  ##
  # x_pos : x-axis representation of position
  # y_pos : y-axis representation of position
  # Moves : Total number of moves made : Will be an array capturing the direction
  # cost : Overall cost incurred while traveling
  ##
	
	def __init__(self, x_pos, y_pos, parent = None,Moves=[],cost=0,):
		global distance_covered

		self.moves_so_far= Moves
		self.cost_so_far= cost
		self.x_pos = x_pos
		self.y_pos = y_pos
		self.pos = (x_pos,y_pos)
		self.parent = parent

	##
    #  Returns the new co-ordinates after moving west
    #
    ##

	def travel_west(self):
		return (self.pos[0]-1, self.pos[1],'W')

	##
    #  Returns the new co-ordinates after moving south
    #
    ##

	def travel_south(self):
		return (self.pos[0],self.pos[1]-1,'S')

	##
    #  Returns the new co-ordinates after moving north
    #
    ##

	def travel_north(self):
		return (self.pos[0],self.pos[1]+1,'N')

	##
    #  Returns the new co-ordinates after moving east
    #
    ##

	def travel_east(self):
		return (self.pos[0]+1,self.pos[1],'E')

	##
    #  Fetches the parent node for a child node
    #
    ##

	def fetch_parent(self):
		return self.parent

	##
    #  Updates the cost
    #
    ##

	def set_cost(self,cost_incurred):
		self.cost_so_far = cost_incurred                    

	##
    #  Updates the parent for a child node
    #
    ##

	def update_parent(self,parent,cost_incurred,distance_covered):
		self.set_cost(cost_incurred)
		self.prev = parent
		self.moves_so_far = parent.moves_so_far[:]
		self.moves_so_far.append(distance_covered)

	##
    #  Returns the string representation of a node
    #
    ##

	def __str__(self):
		return 'Pos={0.pos!s} Moves={0.moves_so_far!s} Cost={0.cost_so_far!s}'.format(self)  	

	##
    #  Fetches the neighbors for a particular node
    #
    ##
		
	def fetch_neighbors(self):
		node_neighbors = [self.travel_north(),self.travel_east(),self.travel_south(),self.travel_west()]		
		return node_neighbors 



