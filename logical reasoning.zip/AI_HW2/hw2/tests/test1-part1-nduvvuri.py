#!/usr/bin/python

from main import resolve

print resolve(["not", "a"],"b")
print resolve(["or", "a", "c"], ["not", "b"])
