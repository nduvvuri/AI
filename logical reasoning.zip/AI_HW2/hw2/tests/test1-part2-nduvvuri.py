#!/usr/bin/python

from main import TELL
from main import ASK

TELL(["or",["not","a"],"b"])
TELL(["or",["not","b"],"c"])
TELL("a")
print(ASK("c"))
print(ASK("d"))
##print(ASK(["or",["or",["not","a"],"c"],"d"]))