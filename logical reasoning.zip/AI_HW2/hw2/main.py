
def createDict(arr) :
    if type(arr) == str:
        return {arr : 0}
    elif len(arr) == 1:
        return {arr[0] : 0}
    elif arr[0] == 'not':
        return {arr[1] : 1}
    elif (arr[0]=='or'):
        res = {}
        subRes = []
        for i in range(1,len(arr)):
            if type(arr[i]) == str:
                res[arr[i]] = 0
            else:
                if arr[i][0] == 'not':
                    res[arr[i][1]] = 1
                elif arr[i][0] == 'or':
                    newRes = createDict(arr[i])
                    subRes.append(newRes) 
                else:
                    return None
        for newRes in subRes:
            for k in newRes:
                if k in res:
                    if (res[k]!=newRes[k]):
                        del(res[k])
                else:
                    res[k] = newRes[k]
        return res
    else:
        return None


def resolve(arr1, arr2) :
    d1 = createDict(arr1)
    d2 = createDict(arr2)

    if (d1 is None or d2 is None):
        return 'False'

    removed = 0
    keys = list(d1.keys())
    for key in keys:
        if key in d2:
            if d2[key] != d1[key] :
                del(d1[key])
                del(d2[key])
                removed = removed + 1
            else:
                del(d2[key])
            if removed == 2 :
                return 'False'
    if removed == 0 :
        return 'False'

    result = []
    for key,val in d1.items():
        if (val == 1):
            result.append(["not", key])
        else:
            result.append(key)
        
    for key,val in d2.items():
        if (val == 1):
            result.append(["not", key])
        else:
            result.append(key)
    
    if len(result) == 1 :
        return result[0]
    if len(result) > 1 :
        result.insert(0, "or")

    return result



knowledge = []

def toList(arr):
    list = []
    if (type(arr) is str):
        list.append(arr)
    else:
        if (arr[0] == "or"):
            for i in range(1,len(arr)):
                result = toList(arr[i])
                if (len(result) == 2 and result[0]=="not"):
                    list.append(result)
                else:
                    list.extend(result)
        elif (arr[0] == "and"):
            for i in range(1,len(arr)):
                list.append(toList(arr[i])) 
        elif (arr[0] == "not"):
            list = arr
    return list

def TELL(arr):
    global knowledge
    toAdd = toList(arr)
    if (type(toAdd) is not str and len(toAdd) > 1 and toAdd[0] is not "or" and toAdd[0] is not "not" and toAdd[0] is not "and"):
        toAdd.insert(0,"or")
    knowledge.append(toAdd)

def negate(arr):
    toReturn = []
    if (type(arr) == str):
        toReturn.append("not")
        toReturn.append(arr)
    else:
        if (arr[0]=="not"):
            toReturn.append(arr[1])
    return toReturn  

def CLEAR():
    global knowledge
    knowledge = []

def ASK(condition):   
    global knowledge
    toAdd = toList(condition)
    if (type(toAdd) is not str and len(toAdd) > 1 and toAdd[0] is not "or" and toAdd[0] is not "not" and toAdd[0] is not "and"):
        toAdd.insert(0,"or")
    checkConditions = []
    #print("->"+str(condition))
    #print("->"+str(toAdd))
    if (len(toAdd) > 0):    
        if (toAdd[0] == "or"):
            for i in range(1,len(toAdd)):
                checkConditions.append(negate(toAdd[i]))
        elif (len(toAdd) == 1):
            toAdd.insert(0,"not")
            checkConditions.append(toAdd)
        else:
            return 'Not CNF'           

    temp_knowledge = list(knowledge)
    temp_knowledge.extend(checkConditions)
    length = len(temp_knowledge)
    #print(checkConditions)
    #print(temp_knowledge)
    while (length > 0):
        toDelete = []
        for i in range(0,length):
            for j in range(i+1,length):
                if (i<len(temp_knowledge) and j<len(temp_knowledge) and temp_knowledge[i] not in toDelete and temp_knowledge[j] not in toDelete):
                    #print("toResolve->" + str(temp_knowledge[i]) + "<-->" + str(temp_knowledge[j]));
                    result = resolve(temp_knowledge[i],temp_knowledge[j])
                    #print("result->"+str(result))
                    #print("<----->")
                    if result=='False':
                        continue
                    else:
                        if result is not None and len(result) > 0:
                            temp_knowledge.append(result)
                        toDelete.append(temp_knowledge[i])
                        toDelete.append(temp_knowledge[j])
                        break
                        
        if len(toDelete)>0:
            temp_knowledge = [x for x in temp_knowledge if x not in toDelete]  
        
        if (length == len(temp_knowledge)):
            return 'False'
    
        if (len(temp_knowledge)==0):
            return 'True'

        length = len(temp_knowledge)

    return 'False'


def main():
    
    #a1 = ["or","b", "c",["or","a","k"]]
    #a2 = ["or",["not","a"],"b",["or","d","e"]]
    #print(a1)
    #print(a2)
    #print(resolve(a1,a2))
    
    a1 = ["or","a","b","c"]
    a2 = ["not","b"]
    print (resolve(a1,a2))

    a1 = ["or","a","b","c"]
    a2 = ["or","b",["not","c"]]
    print(resolve(a1,a2))
    
    a1 = ["or",["not","raining"], "wet ground"]
    a2 = "raining"
    print(resolve(a1,a2))

    a1 = ["or","a","b"]
    a2 = 'c'
    print(resolve(a1,a2))

    a1 = "a"
    a2 = ["not","a"]
    print(resolve(a1,a2))

    
    print("Part 2")
    TELL(["or",["not","a"],"b"])
    TELL(["or",["not","b"],"c"])
    TELL("a")
    print(ASK("c"))
    print(ASK("d"))
    print(ASK(["or",["or",["not","a"],"c"],"d"]))


if __name__== '__main__':
    main()
