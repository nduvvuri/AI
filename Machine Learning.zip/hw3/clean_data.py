import sys
import random

###
# This file curates the input file and cleans up any bad records (records with empty spaces,
# ? ) and writes proper records out to another file.  It also does few additional tasks :
#  1> Re-arranges the class column
#  2> Shuffles the cleaned-up records 
#  3> Slices the entire base dataset into training and testing datasets based on the provided 
#     split percentage
###


if (len(sys.argv)!=4):
    print ("Usage: clean_data.py <dataset file> <dataset name> <training percentage[0-1]>")
    sys.exit(0)

file = sys.argv[1]
name = sys.argv[2]
trainP = sys.argv[3]

lines = []
with open(file) as f:
    content = f.readline()
    while (content!=""):
        if ("?" not in content):
            chunks = content.strip().split(",")
            new_line = ",".join(chunks[1:]) + "," + chunks[0]
            lines.append(new_line)
        content = f.readline()

random.shuffle(lines)
train = len(lines) * float(trainP)
trainfile = name+"-train.csv"
index=0
with open(trainfile,'w') as f:
    while(index<train):
        f.write(lines[index])
        f.write("\n")
        index = index+1

testfile = name+"-test.csv"
with open(testfile,'w') as f:
    while(index<len(lines)):
        f.write(lines[index])
        f.write("\n")
        index = index+1
