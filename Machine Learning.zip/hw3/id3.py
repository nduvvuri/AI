import copy
import dataset

###
#
# The below class implements the ID3 algorithm by reading the input data and builds a decision tree
#
####

class DTree:
    'Represents a decision tree created with the ID3 algorithm'

    ##
    # This function identifies the best way to slice the tree in order to have
    # minimum entropy.
    #  1> Read all the attributes except the classifier attribute.
    #  2> Fetch the dataset / elements individually per attribute and then calculate the attribute entropy
    #  3> Compare the entropy against the minimum recorded entropy
    #  Return Best entropy
    #
    ##


    def getBest(self, classifier, data, attributes):
        minEntropy = 1
        minAttr = "NEW"
        attributeNames = attributes.all_names()
        attributeNames.sort()        
        for attr in attributeNames:
            if attr != classifier.name:
                attrEntropy = 0.0
                for value in attributes[attr].values:
                    subData = dataset.DataSet() 
                    for example in data:
                        if example.get_value(attr) == value:
                            subData.append(example)
                    if len(subData) > 0:
                        attrEntropy = attrEntropy + ( len(subData) * 1.0 / len(data) * 1.0 ) * subData.entropy(classifier)
                if (attrEntropy < minEntropy):
                    minEntropy = attrEntropy
                    minAttr = attributes[attr]
        if (minAttr=="NEW"):
            if classifier.name in attributeNames:
                attributeNames.remove(classifier.name)
            minAttr = attributes[attributeNames[0]]
        return minAttr

        ##
        #  Return the maxAttribute value
        #  Maintain a key-value collection of the counts of each classifier.
        #     Each example in the dataset is parsed and the classifier value is fetched.
        #     It is then checked whether this class already exists in counts, else is added.
        #     If exists, the count of that class in values is bumped up
        #
        #  Later, sort & return the maximum Value of the attribute
        ##

    def getMaxVal(self, classifier, data):
        counts = {}
        for example in data:
            val = example.get_value(classifier)
            if val in counts:
                counts[val] = counts[val] + 1
            else:
                counts[val] = 1

        keys = counts.keys()
        keys.sort()
        maxAtt = keys[0]
        maxVal = counts[maxAtt]
        for key in keys:
            if counts[key] > maxVal:
                maxAtt = key
                maxVal = counts[key]        
        
        return maxAtt

        ##
        #  Maintain a collection of the various output classes [to be classified] under counts.
        #  Maintain a key-value collection of the Maximum counts of each classifier under values.
        #     Each example in the dataset is parsed and the classifier value is fetched.
        #     It is then checked whether this class already exists in counts, else is added.
        #     The count of that class in values is bumped up
        ##



    def getMaxCounts( self, classifier, data):
        counts = {}
        values = {}
        for example in data:
            val = example.get_value(classifier)
            if val in counts:
                counts[val] = counts[val] + 1
            else:
                counts[val]=1
        
        for val in counts.values():
            if val in values:
                values[val] = values[val] + 1
            else:
                values[val] = 1
        
        return counts, values

        ##
        #  Core functionality which builds the Decision Tree.
        ##

    def makeTree( self, classifier, data, attributes, bestVal ):
        tree = {}
        bestAttr = self.getBest(classifier, data, attributes)
        counts,cValues = self.getMaxCounts( classifier,data)
        maxVal = self.getMaxVal( classifier, data) 
        if (cValues[counts[maxVal]] == 1 or maxVal == "null"):
            keys = counts.keys()
            keys.sort()
            bestVal = keys[0]
            for key in keys:
                if counts[key] > counts[bestVal]:
                    bestVal = key 

        subAttributes = copy.copy(attributes)
        subAttributes.remove(bestAttr.name)
        tree[bestAttr.name] = {}
        values = bestAttr.values
        values.sort()
        for val in values:
            subData = dataset.DataSet()
            for example in data:
                if example.get_value(bestAttr.name) == val:
                    subData.append(example) 
            if len(subData) > 0 :
                if (subData.entropy(classifier) == 0 ):
                    tree[bestAttr.name][val] = self.getMaxVal(classifier, subData)
                elif (len(subAttributes) > 0):
                    tree[bestAttr.name][val] = self.makeTree(classifier, subData, subAttributes, bestVal)
                else:
                    counts,cValues = self.getMaxCounts(classifier, subData)
                    maxVal = self.getMaxVal(classifier,data)
                    if cValues[counts[maxVal]] == 1:
                        tree[bestAttr.name][val] = self.getMaxVal(classifier, subData)
                    else:

                        #tree[bestAttr.name][val] = self.getMaxVal(classifier,data)        
                        tree[bestAttr.name][val] = bestVal        
            else:

                #tree[bestAttr.name][val] = self.getMaxVal(classifier,data)
                tree[bestAttr.name][val] = bestVal
                            
        return tree

        ##
        #  Initialize the class by triggering the Tree build in __init() of this class.
        #    Takes in the classifier , training data, input attributes & maximum Value
        ##

    def __init__(self, classifier, training_data, attributes):
        self.tree = self.makeTree(classifier, training_data, attributes,"null")
        return

    def test(self, classifier, testing_data):
        correct = 0
        for example in testing_data:
            testTree = copy.copy(self.tree)
            while(isinstance(testTree,dict)):
                root = testTree.keys()[0]
                testTree = testTree[root][example.get_value(root)]
            if testTree == example.get_value(classifier):
                correct=correct+1
        return correct

        ##
        #  Print the entire decision tree starting from the root node
        #  If the tree is of instance String, parses & builds the  node structure.
        #  If the tree is of instance Dictionary, fetch the root node, and finds keys of
        #  immediate child nodes. Then it iterates over each key and builds the tree
        #
        ##

    
    def printTree( self, tree, depth):  
        if isinstance(tree,str):
            print(''.join([" "]*(depth))+"<" + tree + ">")
        elif (isinstance(tree,dict)):
            rootAttr = tree.keys()[0]
            keys = tree[rootAttr].keys()
            keys.sort()
            for key in keys:
                print(''.join([" "]*(depth))+rootAttr+":"+key)
                self.printTree(tree[rootAttr][key],depth+1)
        return

        ##
        #  Invokes printTree function
        ##


    def dump(self):
        self.printTree(self.tree,0) 
        return ""

